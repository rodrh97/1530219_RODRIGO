<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_DATABASE', 'user');
	define('DB_PASSWORD', 'usbw');
	define('DB_PORT', 8084);

?>